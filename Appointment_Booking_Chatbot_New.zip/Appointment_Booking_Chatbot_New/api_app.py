# api_app.py
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import pandas as pd
import os
from datetime import datetime

API_CSV = "appointments.csv"

app = FastAPI(title="Vidai Clinic Appointment API")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure file exists
if not os.path.exists(API_CSV):
    df_init = pd.DataFrame(columns=[
        "first_name", "last_name", "sex", "mobile", "dob", "email",
        "partner_included", "partner_first", "partner_last", "department",
        "doctor", "date", "time_slot", "reason", "summary", "created_at"
    ])
    df_init.to_csv(API_CSV, index=False)

class Appointment(BaseModel):
    first_name: str
    last_name: str
    sex: str
    mobile: str
    dob: str
    email: str
    partner_included: bool = False
    partner_first: str = ""
    partner_last: str = ""
    department: str
    doctor: str
    date: str
    time_slot: str
    reason: str
    summary: str = ""
    created_at: Optional[str] = None

class ExpertCallback(BaseModel):
    name: str
    phone: str
    email: str = ""
    preference: str = "Phone Call"
    type: str = "expert_callback"

@app.get("/api/appointments", response_model=List[Appointment])
def get_appointments():
    try:
        df = pd.read_csv(API_CSV)
        return df.to_dict(orient="records")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading appointments: {str(e)}")

@app.post("/api/appointments", status_code=201)
def create_appointment(appt: Appointment):
    try:
        df = pd.read_csv(API_CSV)
        
        # Add creation timestamp if not provided
        appt_dict = appt.dict()
        if not appt_dict.get('created_at'):
            appt_dict['created_at'] = datetime.now().isoformat()
        
        df = pd.concat([df, pd.DataFrame([appt_dict])], ignore_index=True)
        df.to_csv(API_CSV, index=False)
        return {"status": "ok", "message": "Appointment saved successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error saving appointment: {str(e)}")

@app.post("/api/expert-callback", status_code=201)
def request_expert_callback(callback: ExpertCallback):
    try:
        df = pd.read_csv(API_CSV)
        
        callback_dict = callback.dict()
        callback_dict['created_at'] = datetime.now().isoformat()
        
        # Convert to appointment-like format for storage
        callback_record = {
            "first_name": callback_dict.get('name', '').split(' ')[0] if callback_dict.get('name') else '',
            "last_name": ' '.join(callback_dict.get('name', '').split(' ')[1:]) if callback_dict.get('name') else '',
            "sex": "",
            "mobile": callback_dict.get('phone', ''),
            "dob": "",
            "email": callback_dict.get('email', ''),
            "partner_included": False,
            "partner_first": "",
            "partner_last": "",
            "department": "Expert Consultation",
            "doctor": "Fertility Specialist",
            "date": "",
            "time_slot": "",
            "reason": f"Expert callback requested - {callback_dict.get('preference', 'Phone Call')}",
            "summary": f"Expert callback: {callback_dict.get('name')} - {callback_dict.get('phone')}",
            "created_at": callback_dict['created_at']
        }
        
        df = pd.concat([df, pd.DataFrame([callback_record])], ignore_index=True)
        df.to_csv(API_CSV, index=False)
        return {"status": "ok", "message": "Expert callback requested successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error saving callback request: {str(e)}")

@app.get("/api/health")
def health_check():
    return {"status": "healthy", "service": "Vidai Clinic Appointment API"}

@app.get("/")
def read_root():
    return {
        "message": "Vidai Clinic Appointment API is running",
        "endpoints": {
            "GET /api/appointments": "Get all appointments",
            "POST /api/appointments": "Create new appointment",
            "POST /api/expert-callback": "Request expert callback",
            "GET /api/health": "Health check"
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)