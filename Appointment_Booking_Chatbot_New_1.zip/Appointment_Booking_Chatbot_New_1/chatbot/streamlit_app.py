# streamlit_app.py
import streamlit as st
import pandas as pd
import os
import requests
import re
from datetime import datetime
from euriai import EuriaiClient
from dotenv import load_dotenv
load_dotenv()

# ---------- Configuration ----------
EURI_KEY = os.environ.get("EURI_API_KEY")
EURI_MODEL = "gpt-4.1-mini"
API_BASE_URL = os.getenv("POC_API_URL", "http://localhost:8000")
APPT_CSV = "appointments.csv"

# Initialize Euri client
if not EURI_KEY:
    st.error("EURI_API_KEY environment variable not found. Please set it and restart.")
    st.stop()

try:
    client = EuriaiClient(api_key=EURI_KEY, model=EURI_MODEL)
except Exception as e:
    st.error(f"Error initializing EURI client: {e}")
    st.stop()

# ---------- Clinic Data ----------
CLINIC_LOCATION = "Vidai Clinic, San Diego, California"
CLINIC_HOURS = "Mon-Sat, 9:00 AM - 7:00 PM"
CLINIC_PHONE = "+1 (619) 555-0123"

DUMMY_DATA = {
    "Fertility / IVF": [
        {"name": "Dr. Priya Nair", "slots": ["10:00 AM", "10:30 AM", "11:00 AM"]},
        {"name": "Dr. Rhea Thomas", "slots": ["2:00 PM", "3:00 PM", "5:00 PM"]},
        {"name": "Dr. Vikram Singh", "slots": ["9:00 AM", "1:00 PM", "4:00 PM"]}
    ],
    "Andrology": [
        {"name": "Dr. Arun Menon", "slots": ["11:00 AM", "1:00 PM", "4:00 PM"]},
        {"name": "Dr. Sanjay Gupta", "slots": ["10:30 AM", "2:30 PM", "3:30 PM"]},
        {"name": "Dr. Rohit Verma", "slots": ["9:30 AM", "12:30 PM", "5:30 PM"]}
    ],
    "Genetic Counseling": [
        {"name": "Dr. Meera Kapoor", "slots": ["9:30 AM", "10:30 AM", "11:30 AM"]},
        {"name": "Dr. Anil Desai", "slots": ["1:30 PM", "3:30 PM", "4:30 PM"]},
        {"name": "Dr. Leena Shah", "slots": ["11:30 AM", "4:30 PM", "5:30 PM"]}
    ],
    "Counselling": [
        {"name": "Dr. Kavita Rao", "slots": ["12:00 PM", "2:30 PM", "4:00 PM"]},
        {"name": "Dr. Nisha Patel", "slots": ["10:00 AM", "1:00 PM", "3:00 PM"]},
        {"name": "Dr. Suresh Iyer", "slots": ["9:00 AM", "11:00 AM", "5:00 PM"]}
    ],
    "Gynecology / Reproductive Endocrinology": [
        {"name": "Dr. Seema Iyer", "slots": ["3:30 PM", "4:30 PM", "5:30 PM"]},
        {"name": "Dr. Ananya Sen", "slots": ["9:30 AM", "12:30 PM", "2:30 PM"]},
        {"name": "Dr. Ritu Malhotra", "slots": ["10:30 AM", "1:30 PM", "3:30 PM"]}
    ]
}

TREATMENT_COSTS = {
    "IVF / ICSI": "$1,200 - $1,500",
    "IUI": "$800 - $1,200",
    "Egg Freezing": "$700 - $1,000",
    "Genetic Counseling": "$500 - $800",
    "Male Infertility": "$300 - $600",
    "Donor Programs": "$2,000 - $3,000"
}

# Ensure CSV file exists
if not os.path.exists(APPT_CSV):
    df_init = pd.DataFrame(columns=[
        "first_name", "last_name", "sex", "mobile", "dob", "email",
        "partner_included", "partner_first", "partner_last", "department",
        "doctor", "date", "time_slot", "reason", "summary", "created_at"
    ])
    df_init.to_csv(APPT_CSV, index=False)

# ---------- Streamlit UI ----------
st.set_page_config(page_title="Vidai Clinic", layout="centered")
st.title("🏥 Vidai Clinic - San Diego")
st.write("**Your journey to parenthood begins here. We're here to help you every step of the way.**")

# Initialize session state
if "step" not in st.session_state:
    st.session_state.step = 0
    st.session_state.form = {}
    st.session_state.messages = []
    st.session_state.current_menu = "main"
    st.session_state.welcome_shown = False
    st.session_state.edit_mode = False
    st.session_state.edit_field = None
    st.session_state.field_history = {}
    st.session_state.appointment_confirmed = False

# Helper to add bot message
def bot_say(text):
    st.session_state.messages.append({"who": "bot", "text": text})

# Helper to add user message with proper field labeling
def user_say(text, field_name=None):
    if field_name and st.session_state.current_menu == "appointment":
        display_name = field_name.replace("_", " ").title()
        st.session_state.messages.append({"who": "user", "text": text, "field": display_name})
        # Store field history for edit functionality
        st.session_state.field_history[field_name] = text
    else:
        st.session_state.messages.append({"who": "user", "text": text})

# Show messages with proper field labeling
def render_messages():
    for i, m in enumerate(st.session_state.messages):
        if m["who"] == "bot":
            st.markdown(f"{m['text']}")
        else:
            # Display field labels for form inputs
            if "field" in m and m["field"]:
                st.markdown(f"**{m['field']}:** {m['text']}")
            else:
                st.markdown(f"**You:** {m['text']}")

# Date validation functions
def validate_dob(dob_str):
    """Validate date of birth - must be at least 21 years old"""
    try:
        dob = datetime.strptime(dob_str, "%m/%d/%Y")
        today = datetime.now()
        age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
        if age < 21:
            return False, "Patient must be at least 21 years old"
        return True, "Valid"
    except ValueError:
        return False, "Invalid date format. Please use MM/DD/YYYY"

def validate_appointment_date(date_str):
    """Validate appointment date - must be in future and correct format"""
    try:
        appt_date = datetime.strptime(date_str, "%m/%d/%Y")
        today = datetime.now().date()
        if appt_date.date() <= today:
            return False, "Appointment date must be in the future"
        return True, "Valid"
    except ValueError:
        return False, "Invalid date format. Please use MM/DD/YYYY"

def validate_mobile(mobile_str):
    """Validate mobile number - 10 digits with optional country code"""
    # Remove any spaces, dashes, parentheses
    cleaned = re.sub(r'[\s\-\(\)\+]', '', mobile_str)
    
    # Check if it's a valid number
    if not cleaned.isdigit():
        return False, "Mobile number should contain only digits and optional country code"
    
    # Check length (10 digits for US numbers, 10-15 for international with country code)
    if len(cleaned) < 10 or len(cleaned) > 15:
        return False, "Mobile number should be 10 digits (with optional country code)"
    
    # If it starts with 1 (US country code), remove it and check if remaining is 10 digits
    if cleaned.startswith('1') and len(cleaned) == 11:
        cleaned = cleaned[1:]
    
    if len(cleaned) != 10:
        return False, "Invalid mobile number format. Please use 10-digit number with optional country code"
    
    return True, "Valid"

# Main menu options - show only once
def show_main_menu():
    if not st.session_state.welcome_shown:
        bot_say("""Hi there! 👨‍⚕️ Welcome to *Vidai Clinic*!
I'm your virtual assistant. How can I help you today?

**Options:**
1️⃣ Book an Appointment
2️⃣ Learn About Treatments
3️⃣ Cost / Packages
4️⃣ Talk to a Fertility Expert
5️⃣ Know About Success Stories
6️⃣ Get Clinic Location & Timings""")
        st.session_state.welcome_shown = True

# Expert consultation with improved UI matching the screenshot
def show_expert_consultation():
    bot_say("""**👨‍⚕️ Talk to a Fertility Expert**

We'd be happy to connect you with our fertility specialists! Please share your details and we'll contact you.""")
    
    # Create a form-like UI similar to the reference screenshot
    st.markdown("---")
    st.subheader("Contact Information")
    
    # Two-column layout matching the screenshot
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Your Name**")
        exp_name = st.text_input("Your Name", key="exp_name", label_visibility="collapsed")
        
        st.markdown("**Mobile Number**")
        exp_phone = st.text_input("Mobile Number", key="exp_phone", label_visibility="collapsed")
    
    with col2:
        st.markdown("**Email ID**")
        exp_email = st.text_input("Email ID", key="exp_email", label_visibility="collapsed")
        
        st.markdown("**Preferred Contact**")
        exp_preference = st.selectbox("Preferred Contact", 
                                    ["Phone Call", "Video Consultation", "Either"], 
                                    key="exp_pref", 
                                    label_visibility="collapsed")
    
    # Request Expert Callback button in green color
    st.markdown("---")
    if st.button("**Request Expert Callback**", key="exp_callback", type="primary", 
                use_container_width=True, 
                help="Click to request a callback from our fertility expert"):
        if exp_name and exp_phone:
            # Validate mobile number
            is_valid, mobile_msg = validate_mobile(exp_phone)
            if not is_valid:
                st.warning(mobile_msg)
                return
                
            user_say(f"Requested callback from {exp_name}")
            
            # Generate confirmation message using EURI
            try:
                prompt = f"""Create a warm confirmation message for a fertility clinic callback request. 
                Include: thanking the patient by name, confirming contact method, and reassuring them about the callback timing.
                End with: Warm regards, Vidai Clinic
                
                Patient: {exp_name}
                Contact: {exp_phone}
                Method: {exp_preference}"""
                resp = client.generate_completion(prompt=prompt, temperature=0.2, max_tokens=150)
                callback_msg = resp.get("choices", [{}])[0].get("message", {}).get("content", "")
            except Exception as e:
                callback_msg = f"Thank you {exp_name}! Our fertility expert will contact you within 24 hours at {exp_phone} via {exp_preference.lower()}.\n\nWarm regards,\nVidai Clinic"
            
            bot_say(callback_msg)
            
            # Save callback request to API
            try:
                callback_data = {
                    "name": exp_name,
                    "phone": exp_phone,
                    "email": exp_email,
                    "preference": exp_preference,
                    "type": "expert_callback"
                }
                response = requests.post(f"{API_BASE_URL}/api/expert-callback", json=callback_data)
                if response.status_code == 201:
                    st.success("✅ Expert callback requested successfully!")
                else:
                    st.warning("Callback request saved locally but API returned an error.")
            except Exception as e:
                # Fallback to local storage
                try:
                    callback_record = {
                        "first_name": exp_name.split(' ')[0] if exp_name else '',
                        "last_name": ' '.join(exp_name.split(' ')[1:]) if exp_name else '',
                        "sex": "",
                        "mobile": exp_phone,
                        "dob": "",
                        "email": exp_email,
                        "partner_included": False,
                        "partner_first": "",
                        "partner_last": "",
                        "department": "Expert Consultation",
                        "doctor": "Fertility Specialist",
                        "date": "",
                        "time_slot": "",
                        "reason": f"Expert callback requested - {exp_preference}",
                        "summary": f"Expert callback: {exp_name} - {exp_phone}",
                        "created_at": datetime.now().isoformat()
                    }
                    df = pd.read_csv(APPT_CSV)
                    df = pd.concat([df, pd.DataFrame([callback_record])], ignore_index=True)
                    df.to_csv(APPT_CSV, index=False)
                    st.success("✅ Expert callback requested successfully!")
                except Exception as e2:
                    st.error(f"Error saving callback request: {e2}")
            
            st.rerun()
        else:
            st.warning("Please provide at least your name and mobile number.")
    
    st.markdown("---")
    if st.button("🔙 Back to Main", key="exp_back"):
        user_say("Back to Main Menu")
        st.session_state.current_menu = "main"
        st.rerun()

# Book Appointment UI with all fields on one page
def show_appointment_form():
    st.markdown("---")
    
    # Show edit options when in edit mode
    if st.session_state.edit_mode:
        show_edit_options()
        return

    # Show appointment form with all fields on one page
    if st.session_state.step == 1:
        st.subheader("Appointment Information")
        
        # Personal Information - Two columns
        st.markdown("**Personal Information**")
        col1, col2 = st.columns(2)
        
        with col1:
            first_name = st.text_input(
                "**First Name**", 
                value=st.session_state.form.get("first_name", ""),
                placeholder="Enter your first name",
                key="first_name"
            )
            
            sex = st.selectbox(
                "**Sex**",
                options=["", "Male", "Female", "Other", "Prefer not to say"],
                index=0,
                key="sex"
            )
            
            dob = st.text_input(
                "**Date of Birth**", 
                value=st.session_state.form.get("dob", ""),
                placeholder="MM/DD/YYYY (must be at least 21 years old)",
                key="dob"
            )
            
            department = st.selectbox(
                "**Department**",
                options=[""] + list(DUMMY_DATA.keys()),
                index=0,
                key="department"
            )
            
            date = st.text_input(
                "**Preferred Date**", 
                value=st.session_state.form.get("date", ""),
                placeholder="MM/DD/YYYY",
                key="date"
            )
        
        with col2:
            last_name = st.text_input(
                "**Last Name**", 
                value=st.session_state.form.get("last_name", ""),
                placeholder="Enter your last name",
                key="last_name"
            )
            
            mobile = st.text_input(
                "**Mobile Number**", 
                value=st.session_state.form.get("mobile", ""),
                placeholder="Enter your mobile number with country code",
                key="mobile"
            )
            
            email = st.text_input(
                "**Email ID**", 
                value=st.session_state.form.get("email", ""),
                placeholder="Enter your email address",
                key="email"
            )
            
            # Doctor selection based on department
            doctor_options = [""]
            if department and department in DUMMY_DATA:
                doctor_options.extend([d["name"] for d in DUMMY_DATA[department]])
            
            doctor = st.selectbox(
                "**Select Doctor**",
                options=doctor_options,
                index=0,
                key="doctor"
            )
            
            # Time slot selection based on doctor
            time_options = [""]
            if department and doctor and doctor != "":
                for d in DUMMY_DATA.get(department, []):
                    if d["name"] == doctor:
                        time_options.extend(d["slots"])
                        break
            
            time_slot = st.selectbox(
                "**Time Slot**",
                options=time_options,
                index=0,
                key="time_slot"
            )
        
        # Partner Information
        st.markdown("---")
        st.markdown("**Partner Information**")
        partner_col1, partner_col2 = st.columns(2)
        
        with partner_col1:
            partner_included = st.selectbox(
                "**Include Partner**",
                options=["No", "Yes"],
                index=0 if st.session_state.form.get("partner_included", "No") == "No" else 1,
                key="partner_included"
            )
        
        with partner_col2:
            if partner_included == "Yes":
                partner_first = st.text_input(
                    "**Partner First Name**", 
                    value=st.session_state.form.get("partner_first", ""),
                    placeholder="Enter partner's first name",
                    key="partner_first"
                )
                
                partner_last = st.text_input(
                    "**Partner Last Name**", 
                    value=st.session_state.form.get("partner_last", ""),
                    placeholder="Enter partner's last name",
                    key="partner_last"
                )
            else:
                partner_first = ""
                partner_last = ""
        
        # Reason for appointment
        st.markdown("---")
        reason = st.text_area(
            "**Reason for Appointment**",
            value=st.session_state.form.get("reason", ""),
            placeholder="Briefly describe your reason for appointment",
            key="reason",
            height=100
        )
        
        # Action buttons at the bottom
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 1, 1])
        
        with col1:
            if st.button("🔙 Back to Main", use_container_width=True):
                st.session_state.current_menu = "main"
                st.rerun()
        
        with col2:
            if st.button("📋 Show Summary", type="primary", use_container_width=True):
                # Validate all required fields
                validation_passed = True
                validation_errors = []
                
                if not first_name:
                    validation_errors.append("First Name is required")
                    validation_passed = False
                
                if not last_name:
                    validation_errors.append("Last Name is required")
                    validation_passed = False
                
                if not sex:
                    validation_errors.append("Sex is required")
                    validation_passed = False
                
                if not mobile:
                    validation_errors.append("Mobile Number is required")
                    validation_passed = False
                else:
                    is_valid, mobile_msg = validate_mobile(mobile)
                    if not is_valid:
                        validation_errors.append(f"Mobile: {mobile_msg}")
                        validation_passed = False
                
                if not dob:
                    validation_errors.append("Date of Birth is required")
                    validation_passed = False
                else:
                    is_valid, dob_msg = validate_dob(dob)
                    if not is_valid:
                        validation_errors.append(f"Date of Birth: {dob_msg}")
                        validation_passed = False
                
                if not email:
                    validation_errors.append("Email is required")
                    validation_passed = False
                elif "@" not in email or "." not in email:
                    validation_errors.append("Please enter a valid email address")
                    validation_passed = False
                
                if not department:
                    validation_errors.append("Department is required")
                    validation_passed = False
                
                if not doctor:
                    validation_errors.append("Doctor is required")
                    validation_passed = False
                
                if not date:
                    validation_errors.append("Appointment Date is required")
                    validation_passed = False
                else:
                    is_valid, date_msg = validate_appointment_date(date)
                    if not is_valid:
                        validation_errors.append(f"Appointment Date: {date_msg}")
                        validation_passed = False
                
                if not time_slot:
                    validation_errors.append("Time Slot is required")
                    validation_passed = False
                
                if partner_included == "Yes" and (not partner_first or not partner_last):
                    validation_errors.append("Partner First and Last Name are required when including partner")
                    validation_passed = False
                
                if not reason:
                    validation_errors.append("Reason for Appointment is required")
                    validation_passed = False
                
                if validation_passed:
                    # Store all form data
                    form_data = {
                        "first_name": first_name,
                        "last_name": last_name,
                        "sex": sex,
                        "mobile": mobile,
                        "dob": dob,
                        "email": email,
                        "partner_included": partner_included,
                        "partner_first": partner_first,
                        "partner_last": partner_last,
                        "department": department,
                        "doctor": doctor,
                        "date": date,
                        "time_slot": time_slot,
                        "reason": reason
                    }
                    st.session_state.form.update(form_data)
                    
                    # Store field history for chat display
                    for key, value in form_data.items():
                        if value:
                            user_say(value, key)
                    
                    st.session_state.step = 2  # Move to summary
                    st.rerun()
                else:
                    for error in validation_errors:
                        st.error(error)
        
        with col3:
            if st.session_state.form:
                if st.button("✏️ Edit Details", use_container_width=True):
                    st.session_state.edit_mode = True
                    st.rerun()

    # Summary step
    elif st.session_state.step == 2:
        show_appointment_summary()

# Show appointment summary in tabular format
def show_appointment_summary():
    form = st.session_state.form
    st.markdown("### 📋 Appointment Summary")
    
    # Create summary data for tabular display
    summary_data = []
    
    # Personal Information
    summary_data.append(["**Personal Information**", ""])
    summary_data.append(["First Name", form.get("first_name", "")])
    summary_data.append(["Last Name", form.get("last_name", "")])
    summary_data.append(["Sex", form.get("sex", "")])
    summary_data.append(["Date of Birth", form.get("dob", "")])
    summary_data.append(["Email", form.get("email", "")])
    summary_data.append(["Mobile", form.get("mobile", "")])
    
    # Partner Information if included
    if form.get("partner_included", "").lower() == "yes":
        summary_data.append(["", ""])
        summary_data.append(["**Partner Information**", ""])
        summary_data.append(["Partner First Name", form.get("partner_first", "")])
        summary_data.append(["Partner Last Name", form.get("partner_last", "")])
    
    # Appointment Details
    summary_data.append(["", ""])
    summary_data.append(["**Appointment Details**", ""])
    summary_data.append(["Department", form.get("department", "")])
    summary_data.append(["Doctor", form.get("doctor", "")])
    summary_data.append(["Date", form.get("date", "")])
    summary_data.append(["Time Slot", form.get("time_slot", "")])
    summary_data.append(["Reason", form.get("reason", "")])
    
    # Display summary in a table format
    for row in summary_data:
        col1, col2 = st.columns([1, 2])
        with col1:
            st.write(row[0])
        with col2:
            st.write(row[1])
    
    # Action buttons - side by side
    st.markdown("### Confirm Your Appointment")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("✅ **Confirm Appointment**", type="primary", use_container_width=True):
            confirm_appointment()
    
    with col2:
        if st.button("✏️ **Edit Details**", use_container_width=True):
            user_say("Edit appointment details")
            st.session_state.edit_mode = True
            st.rerun()
    
    with col3:
        if st.button("❌ **Cancel**", use_container_width=True):
            user_say("Cancel appointment")
            st.info("Appointment cancelled.")
            st.session_state.step = 0
            st.session_state.form = {}
            st.session_state.current_menu = "main"
            st.rerun()

# Confirm appointment and show confirmation
def confirm_appointment():
    form = st.session_state.form
    user_say("Confirm appointment")
    
    # Generate confirmation message using EURI
    try:
        prompt = f"""Create a warm, professional confirmation message for a fertility clinic appointment. 
        Include: patient name, doctor, date/time, and a reassuring tone. Keep it to 3-4 sentences.
        End with: Thank you for choosing Vidai Clinic!
        
        Details: 
        Patient: {form.get('first_name', '')} {form.get('last_name', '')}
        Doctor: {form.get('doctor', '')}
        Date: {form.get('date', '')}
        Time: {form.get('time_slot', '')}"""
        resp = client.generate_completion(prompt=prompt, temperature=0.2, max_tokens=200)
        confirmation_msg = resp.get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception as e:
        confirmation_msg = f"Thank you {form.get('first_name', '')}! Your appointment with {form.get('doctor', '')} on {form.get('date', '')} at {form.get('time_slot', '')} has been confirmed. We look forward to seeing you! Warm regards, Vidai Clinic"
    
    # Prepare appointment data for API
    appointment_data = {
        "first_name": form.get("first_name", ""),
        "last_name": form.get("last_name", ""),
        "sex": form.get("sex", ""),
        "mobile": form.get("mobile", ""),
        "dob": form.get("dob", ""),
        "email": form.get("email", ""),
        "partner_included": form.get("partner_included", "").lower() == "yes",
        "partner_first": form.get("partner_first", ""),
        "partner_last": form.get("partner_last", ""),
        "department": form.get("department", ""),
        "doctor": form.get("doctor", ""),
        "date": form.get("date", ""),
        "time_slot": form.get("time_slot", ""),
        "reason": form.get("reason", ""),
        "summary": "Appointment booked via Vidai Clinic chatbot"
    }
    
    # Save to API
    try:
        response = requests.post(f"{API_BASE_URL}/api/appointments", json=appointment_data)
        if response.status_code in (200, 201):
            st.success("✅ Appointment saved successfully via API!")
        else:
            st.warning("Appointment saved locally but API returned an error.")
    except Exception as e:
        # Fallback to local storage
        try:
            appointment_data["created_at"] = datetime.now().isoformat()
            df = pd.read_csv(APPT_CSV)
            df = pd.concat([df, pd.DataFrame([appointment_data])], ignore_index=True)
            df.to_csv(APPT_CSV, index=False)
            st.success("✅ Appointment saved locally!")
        except Exception as e2:
            st.error(f"Error saving appointment: {e2}")

    bot_say(confirmation_msg)
    st.session_state.appointment_confirmed = True
    st.session_state.step = 0
    st.session_state.form = {}
    st.session_state.current_menu = "main"
    st.rerun()

# Edit appointment functionality - specific field editing
def show_edit_options():
    st.markdown("---")
    st.subheader("✏️ Edit Appointment Details")
    st.write("Select which field you'd like to edit:")
    
    form = st.session_state.form
    
    # Create edit fields in the same two-column layout
    col1, col2 = st.columns(2)
    
    edit_fields = [
        {"key": "first_name", "display": "First Name", "value": form.get("first_name", ""), "col": 1},
        {"key": "last_name", "display": "Last Name", "value": form.get("last_name", ""), "col": 2},
        {"key": "sex", "display": "Sex", "value": form.get("sex", ""), "col": 1},
        {"key": "mobile", "display": "Mobile Number", "value": form.get("mobile", ""), "col": 2},
        {"key": "dob", "display": "Date of Birth", "value": form.get("dob", ""), "col": 1},
        {"key": "email", "display": "Email ID", "value": form.get("email", ""), "col": 2},
        {"key": "department", "display": "Department", "value": form.get("department", ""), "col": 1},
        {"key": "doctor", "display": "Doctor", "value": form.get("doctor", ""), "col": 2},
        {"key": "date", "display": "Preferred Date", "value": form.get("date", ""), "col": 1},
        {"key": "time_slot", "display": "Time Slot", "value": form.get("time_slot", ""), "col": 2},
        {"key": "partner_included", "display": "Include Partner", "value": form.get("partner_included", ""), "col": 1},
        {"key": "partner_first", "display": "Partner First Name", "value": form.get("partner_first", ""), "col": 2},
        {"key": "partner_last", "display": "Partner Last Name", "value": form.get("partner_last", ""), "col": 1},
        {"key": "reason", "display": "Reason", "value": form.get("reason", ""), "col": 2},
    ]
    
    updated_form = form.copy()
    
    for field in edit_fields:
        if field["col"] == 1:
            with col1:
                if field["key"] in ["sex", "department", "doctor", "time_slot", "partner_included"]:
                    # Select boxes for these fields
                    if field["key"] == "sex":
                        options = ["", "Male", "Female", "Other", "Prefer not to say"]
                        current_index = options.index(field["value"]) if field["value"] in options else 0
                        updated_value = st.selectbox(field["display"], options, index=current_index, key=f"edit_{field['key']}")
                    elif field["key"] == "department":
                        options = [""] + list(DUMMY_DATA.keys())
                        current_index = options.index(field["value"]) if field["value"] in options else 0
                        updated_value = st.selectbox(field["display"], options, index=current_index, key=f"edit_{field['key']}")
                    elif field["key"] == "doctor":
                        dept = updated_form.get("department", form.get("department", ""))
                        options = [""]
                        if dept and dept in DUMMY_DATA:
                            options.extend([d["name"] for d in DUMMY_DATA[dept]])
                        current_index = options.index(field["value"]) if field["value"] in options else 0
                        updated_value = st.selectbox(field["display"], options, index=current_index, key=f"edit_{field['key']}")
                    elif field["key"] == "time_slot":
                        dept = updated_form.get("department", form.get("department", ""))
                        doctor = updated_form.get("doctor", form.get("doctor", ""))
                        options = [""]
                        if dept and doctor and doctor != "":
                            for d in DUMMY_DATA.get(dept, []):
                                if d["name"] == doctor:
                                    options.extend(d["slots"])
                                    break
                        current_index = options.index(field["value"]) if field["value"] in options else 0
                        updated_value = st.selectbox(field["display"], options, index=current_index, key=f"edit_{field['key']}")
                    elif field["key"] == "partner_included":
                        options = ["No", "Yes"]
                        current_index = options.index(field["value"]) if field["value"] in options else 0
                        updated_value = st.selectbox(field["display"], options, index=current_index, key=f"edit_{field['key']}")
                    updated_form[field["key"]] = updated_value
                else:
                    # Text inputs for other fields
                    updated_value = st.text_input(field["display"], value=field["value"], key=f"edit_{field['key']}")
                    updated_form[field["key"]] = updated_value
        else:
            with col2:
                if field["key"] == "reason":
                    updated_value = st.text_area(field["display"], value=field["value"], height=100, key=f"edit_{field['key']}")
                    updated_form[field["key"]] = updated_value
                else:
                    updated_value = st.text_input(field["display"], value=field["value"], key=f"edit_{field['key']}")
                    updated_form[field["key"]] = updated_value
    
    # Action buttons
    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("✅ **Save Changes**", type="primary", use_container_width=True):
            st.session_state.form = updated_form
            st.session_state.edit_mode = False
            # Update chat messages with edited fields
            for key, value in updated_form.items():
                if value != form.get(key):
                    user_say(value, key)
            st.rerun()
    with col2:
        if st.button("❌ **Cancel Editing**", use_container_width=True):
            st.session_state.edit_mode = False
            st.rerun()

# Cost information with personalized quote line
def show_cost_info():
    bot_say("""**💰 Treatment Costs & Packages**""")
    
    for treatment, cost in TREATMENT_COSTS.items():
        st.write(f"**{treatment}:** {cost}")
    
    st.markdown("---")
    st.info(f"💡 **For detailed pricing and personalized quotes, please call us at {CLINIC_PHONE}**")
    
    if st.button("🔙 Back to Main"):
        st.session_state.current_menu = "main"
        st.rerun()

# Location information with EURI API
def show_location_info():
    bot_say(f"""**📍 Clinic Location & Timings**

🏥 **{CLINIC_LOCATION}**
⏰ **Hours:** {CLINIC_HOURS}
📞 **Phone:** {CLINIC_PHONE}""")
    
    # Generate location description using EURI
    try:
        location_prompt = f"""Generate a brief, welcoming description of a fertility clinic location in San Diego, California. 
        Include information about parking facilities, accessibility, neighborhood amenities, and clinic facilities.
        Keep it to 3-4 sentences and make it inviting for patients."""
        resp = client.generate_completion(prompt=location_prompt, temperature=0.3, max_tokens=150)
        location_desc = resp.get("choices", [{}])[0].get("message", {}).get("content", "")
        st.write(location_desc)
    except Exception as e:
        st.write("Our state-of-the-art facility in San Diego offers comfortable, private consultation rooms and advanced medical equipment. We provide ample parking facilities and are easily accessible from all major areas of San Diego. Our clinic features modern amenities to ensure your comfort throughout your visit.")
    
    if st.button("🔙 Back to Main"):
        st.session_state.current_menu = "main"
        st.rerun()

# Treatments information with EURI API
def show_treatments_info():
    bot_say("**💡 Learn About Treatments**")
    
    treatment = st.selectbox("Select Treatment", list(TREATMENT_COSTS.keys()) + ["All Treatments Overview"])
    
    if st.button("Get Info"):
        user_say(f"Learn about {treatment}")
        
        try:
            if treatment == "All Treatments Overview":
                prompt = f"""Provide a comprehensive overview of fertility treatments including IVF, IUI, egg freezing, genetic counseling, male infertility treatments, and donor programs.
                Explain each treatment briefly (1-2 sentences each) and mention who they are suitable for.
                Keep the tone professional yet patient-friendly and encouraging."""
            else:
                prompt = f"""Provide a detailed 3-4 sentence description of {treatment} fertility treatment. 
                Explain what the treatment involves, who it's suitable for, and what patients can expect.
                Include key benefits and keep it patient-friendly, informative, and reassuring."""
            
            resp = client.generate_completion(prompt=prompt, temperature=0.3, max_tokens=200)
            treatment_info = resp.get("choices", [{}])[0].get("message", {}).get("content", "")
            bot_say(f"**{treatment}**\n\n{treatment_info}")
        except Exception as e:
            bot_say(f"**{treatment}**\n\nThis treatment helps patients on their fertility journey. Our specialists can provide detailed information during your consultation about the procedure, success rates, and what to expect.")
        
        st.rerun()
    
    if st.button("🔙 Back to Main"):
        st.session_state.current_menu = "main"
        st.rerun()

# Success stories with EURI API
def show_success_stories():
    bot_say("**🌟 Success Stories**")
    
    try:
        stories_prompt = """Generate 3 brief, inspiring fertility treatment success stories (2-3 sentences each). 
        Make them positive and hopeful, include different scenarios like IVF success, egg freezing, and genetic counseling.
        Keep them authentic and emotional, but maintain patient privacy by not using specific names."""
        resp = client.generate_completion(prompt=stories_prompt, temperature=0.4, max_tokens=250)
        stories = resp.get("choices", [{}])[0].get("message", {}).get("content", "")
        st.write(stories)
    except Exception as e:
        st.write("""
        *"After years of trying, the compassionate team at Vidai helped us welcome our beautiful daughter. The entire journey was supported with care and expertise that made all the difference."*
        
        *"The genetic counseling and IVF treatment gave us the confidence we needed. We're now expecting twins and couldn't be happier with our decision to trust Vidai Clinic."*
        
        *"Egg freezing gave me the freedom to focus on my career while preserving my fertility options. The team made the process comfortable and empowering every step of the way."*
        """)
    
    if st.button("🔙 Back to Main"):
        st.session_state.current_menu = "main"
        st.rerun()

# Render appropriate content based on current menu
render_messages()

# Show main menu buttons only when in main menu
if st.session_state.current_menu == "main":
    show_main_menu()
    st.markdown("---")
    st.write("**Choose an option:**")
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("📅 Book Appointment", use_container_width=True):
            user_say("Book an Appointment")
            st.session_state.current_menu = "appointment"
            st.session_state.step = 1
            st.rerun()
        if st.button("💰 Cost / Packages", use_container_width=True):
            user_say("Cost / Packages")
            st.session_state.current_menu = "cost"
            st.rerun()
    with col2:
        if st.button("💡 Learn Treatments", use_container_width=True):
            user_say("Learn About Treatments")
            st.session_state.current_menu = "treatments"
            st.rerun()
        if st.button("📍 Location & Hours", use_container_width=True):
            user_say("Get Clinic Location & Timings")
            st.session_state.current_menu = "location"
            st.rerun()
    with col3:
        if st.button("👨‍⚕️ Talk to Expert", use_container_width=True):
            user_say("Talk to a Fertility Expert")
            st.session_state.current_menu = "expert"
            st.rerun()
        if st.button("🌟 Success Stories", use_container_width=True):
            user_say("Know About Success Stories")
            st.session_state.current_menu = "stories"
            st.rerun()

elif st.session_state.current_menu == "expert":
    show_expert_consultation()

elif st.session_state.current_menu == "appointment":
    show_appointment_form()

elif st.session_state.current_menu == "cost":
    show_cost_info()

elif st.session_state.current_menu == "location":
    show_location_info()

elif st.session_state.current_menu == "treatments":
    show_treatments_info()

elif st.session_state.current_menu == "stories":
    show_success_stories()